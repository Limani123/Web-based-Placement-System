
<html>
<head><title>Coordinator</title>
<link rel="icon" href="iiitgic.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<style>
tr:nth-child(even) {background: #CCC}
tr:nth-child(odd) {background: #675f5f}
</style>
<body>
<div class="w3-bar w3-white w3-card w3-large" >
<img src="header.svg">
</div>
<br><br>
<a href="../Loginadmin.php"><i class="fa fa-arrow-circle-left" style="font-size:36px; align:right;"></i></a>
<br>

<table>

<tr><td width="1400" align="center">
<h1><font color="white">Delete Student</font>
<button onclick="location.href='studentdelete.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
<tr><td width="1400" align="center">
<h1><font color="white">View Students</font>
<button onclick="location.href='viewstudent.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
<tr><td width="1400" align="center">
<h1><font color="white">Student Placement Records</font>
<button onclick="location.href='currentrecord.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
<tr><td width="1400" align="center">
<h1><font color="white">Past Placement Records</font>
<button onclick="location.href='oldrecord.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
</table>
<hr>
<hr><hr><hr>
<table>
<tr><td width="1400" align="center">
<h1><font color="white">Delete Company</font>
<button onclick="location.href='deletecompany.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
<tr><td width="1400" align="center">
<h1><font color="white">View Companies</font>
<button onclick="location.href='viewcompany.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
</table>
<hr>
<hr><hr><hr>
<table>
<tr><td width="1400" align="center">
<h1><font color="white">View Jobs</font>
<button onclick="location.href='viewjobs.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
<tr><td width="1400" align="center">
<h1><font color="white">Delete Jobs</font>
<button onclick="location.href='deletejobs.php'"><i class="fa fa-angle-double-right" style="font-size:28px"></i></h1></button>
</td></tr>
</table>
<hr>
</html>
