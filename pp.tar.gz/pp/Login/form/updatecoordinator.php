<?php
$str="Welcome Admin!";
echo $str;
?>
<html>
<a href="insertcoordinator.php">Insert Coordinator</a>
<br>
<a href="deletecoordinator.php">Delete Coordinator</a>
</html>
